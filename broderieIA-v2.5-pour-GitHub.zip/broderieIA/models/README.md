# Dossier des modèles d'IA

Ce dossier doit contenir `u2netp.onnx` (environ 4,7 Mo), le modèle de détourage U2-Netp.

Pour le télécharger : `sh scripts/download-ai.sh` (voir le guide, partie 49).
Vous pouvez aussi placer ici un autre modèle de détourage au format ONNX compatible
(entrée 320 x 320, sortie : carte de saillance) en le nommant `u2netp.onnx`,
ou le charger à la main avec le bouton « Modèle… » de l'application.

Licences : U2-Netp, Apache-2.0 (Xuebin Qin et al.) ; fichier ONNX distribué par rembg, MIT (Daniel Gatis).
