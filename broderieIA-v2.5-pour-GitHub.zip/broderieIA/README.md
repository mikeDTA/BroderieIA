# Atelier Broderie v2.5 (dépôt broderieIA)

Auteur : Michaël PONCET, https://github.com/mikeDTA

Application web (100 % navigateur, sans serveur) : photo (JPEG, PNG, SVG…) → fichier de broderie **DST** + palette de fils **EDR**, pour Toyota ESP-9000.

© Michaël PONCET — licence CC BY-NC 4.0 (usage non commercial, crédit obligatoire).

## Héberger sur GitHub
1. Créez un dépôt sur github.com (New repository), par exemple `broderieIA`.
2. Cliquez sur **Add file > Upload files**, glissez `index.html`, `LICENSE`, `README.md`, puis **Commit changes**.
3. **Settings > Pages > Source : Deploy from a branch > main / (root)** > Save.
4. Le site est disponible à `https://VOTRE-PSEUDO.github.io/broderieIA/`.

## Utilisation rapide
Importez une image, choisissez tissu et stabilisateur (l'espacement et le tirage s'adaptent), ouvrez **Réglages rapides** ou **Vue avancée**, puis exportez le **DST**.
Cochez **Portrait** pour un rendu hachuré façon dessin, avec option noir et blanc.

## État actuel
Fonctionnel : import de tout format d'image, conversion couleur / niveaux de gris / noir et blanc, simplification des zones (moins de coupes de fil), style de point choisi par couleur (tatami, vrai satin, auto, point droit, contours), fils regroupés par couleur, OCR pour broder l'écriture en satin, sous-couche, portrait, import de palette de fils (.gpl ou CSV), nombre de points et durée estimée, texte brodé, rendu relief, vue 3D tournante (three.js), 15 aiguilles avec choix des fils en direct, exports DST, 10O et EDR,  texte brodé par-dessus l'image, stabilisateurs dessous et dessus par tissu, correspondance des couleurs en Lab, interface sans défilement, déploiement Docker (`Dockerfile`, `docker-compose.yml`, `nginx.conf`), guide en PDF / Markdown / YesWiki dans `docs/`.
Aussi : réglages de points par aiguille (15 couleurs), zigzag, sous-couches de contour et en zigzag, méthodes de remplissage (rangées, contours, cercles, méandre), points de départ, d'arrivée et d'arrêt, rendu 3D avec carte graphique.
Aussi : optimisation automatique des réglages à chaque changement de style, réglages satin et coupe de fil d'Ink/Stitch, point guide des cercles, conteneur Docker v2.4 avec contrôle de santé.
Aussi : import de polices .ttf/.otf, colonnes de satin à rails dessinées à la main, remplissage guidé par une ligne, sous-couche en zigzag du tatami.
Aussi : design plus vif (icônes, thème sombre, glisser-déposer, bulles d'aide), panneaux de réglages qui ne cachent plus le motif.
Aussi : barre de taille du motif, conversion de meilleure qualité (Lab, lissage, saturation, angle automatique), palette de 77 fils, plus de couleurs (6 à 15, jusqu'à 24), portrait en tons jusqu'à 4 couleurs avec texte.
Aussi (v2.4) : fermeture des formes, regroupement des couleurs (jusqu'à 92 % de coupes en moins), zoom et mode agrandir, masquage d'une couleur, plusieurs textes avec polices importées, sens d'export DST/10O réglable.
Aussi (v2.5) : pinceau, gomme et annulation pour corriger les zones sur la photo, détourage par IA open source (U²-Netp, dans le navigateur), conteneur Docker 2.5.
À venir : export EOF (format Embird Studio non documenté), satin plus soigné aux jonctions, réglages Ink/Stitch restants (zigzag, sous-couches de contour, méthodes de remplissage).

## Déploiement avec Docker
`docker compose up -d --build` puis ouvrir http://localhost:8080 (voir le guide, partie 26).

## IA de détourage (facultative)
Pour retirer automatiquement le fond d'une photo, installez le modèle U²-Netp (Apache-2.0) et ONNX Runtime Web (MIT) :

    sh scripts/download-ai.sh

Avec Docker, `docker compose up -d --build` le fait seul (mettre `WITH_AI: "0"` pour l'éviter). Sur GitHub Pages, lancez le script puis envoyez les dossiers `models` et `vendor` dans le dépôt. Détails : guide, partie 49. Licences : `THIRD_PARTY.md`.
