# Atelier Broderie : guide complet pour débutants

© Michaël PONCET, créateur du projet (page GitHub : https://github.com/mikeDTA). Licence CC BY-NC 4.0 : usage non commercial, crédit obligatoire.

Ce guide s'adresse à des personnes qui n'ont aucune habitude de l'informatique. Chaque étape dit exactement sur quoi cliquer. Les captures d'écran montrent l'application avec une image d'exemple (formes colorées).

## Sommaire

- 1. Avant de commencer
- 2. Récupérer le projet depuis votre GitHub
- 3. Installer le projet sur GitHub
- 4. Démarrage rapide
- 5. Comprendre ce qui s'affiche
- 6. Les réglages rapides
- 7. Tous les réglages
- 8. Les types de point
- 9. Couleur, niveaux de gris, noir et blanc
- 10. Le mode portrait
- 11. Ajouter des contours
- 12. La palette de fils Madeira
- 13. Réduire les coupes de fil sans perdre en qualité
- 14. Tissus, stabilisateurs et aiguilles
- 15. Si quelque chose ne va pas
- 16. Broder du texte
- 17. Le rendu relief 3D
- 18. Brodeuse à 15 aiguilles
- 19. Un style de point par couleur
- 20. Le vrai satin et la reconnaissance d'écriture
- 21. La vue 3D tournante
- 22. Les formats d'export
- 24. Faire correspondre les couleurs de l'image et du fil
- 25. Ajouter un texte sur l'image brodée
- 26. Mettre l'application sur un serveur (Kubuntu, Docker)
- 27. Les réglages de chaque aiguille (15 couleurs)
- 28. Zigzag, sous-couches et méthodes de remplissage
- 29. Départ, arrivée et points d'arrêt
- 30. La carte graphique et le rendu 3D
- 31. Optimisation automatique des réglages selon le style
- 32. Autres réglages d'Ink/Stitch
- 33. Importer une police pour le texte
- 34. La colonne de satin à rails
- 35. Le remplissage guidé par une ligne
- 36. La sous-couche en zigzag du tatami
- 37. Se repérer : couleurs, icônes et panneaux
- 38. Redimensionner votre motif
- 39. Plus de couleurs et ajout de couleurs
- 40. Une conversion de meilleure qualité
- 41. Le portrait : jusqu'à 4 couleurs et du texte
- 42. Fermer une forme
- 43. Regrouper les couleurs pour limiter les sauts et les coupes de fil
- 44. Zoom et agrandissement de la photo
- 45. Ne pas afficher une couleur
- 46. Plusieurs textes, plusieurs polices
- 47. Le sens du fichier DST : annuler l'effet miroir
- 48. Corriger les zones directement sur la photo
- 49. Le détourage par IA open source
- 50. Ce qui n'est pas encore disponible
- 51. Journal des versions

## 1. Avant de commencer

- **Navigateur** : le programme que vous utilisez pour aller sur internet (Chrome, Firefox, Edge, Safari).
- **GitHub** : un site gratuit qui range les fichiers d'un projet et peut les mettre en ligne.
- **Dépôt** : le « dossier » du projet sur GitHub.
- **DST** : le fichier de broderie que la machine sait lire. **EDR** : la liste des couleurs de fils.
- **Point** : un trou d'aiguille. **Coupe de fil** : la machine coupe le fil pour passer à une autre zone, ce qui laisse un petit bout de fil à rattraper.
- **Serveur** : un ordinateur toujours allumé qui met l'application à disposition par internet ou dans votre réseau.
- **Docker** : un outil qui range l'application et son serveur web dans une « boîte » prête à démarrer.
- **Terminal** (Konsole sous Kubuntu) : une fenêtre où l'on tape des commandes.
- Vous avez besoin d'un ordinateur, d'une connexion internet, d'une adresse e-mail et d'une photo ou d'un dessin.

## 2. Récupérer le projet depuis votre GitHub

1. Ouvrez votre navigateur et allez sur `https://github.com/mikeDTA/broderieIA`.
2. Cliquez sur le bouton vert **Code**.
3. Cliquez sur **Download ZIP** : un fichier se télécharge, souvent dans le dossier Téléchargements.
4. Faites un clic droit sur ce fichier, puis **Extraire tout** (Windows) ou double-cliquez dessus (Mac).
5. Dans le dossier obtenu, double-cliquez sur `index.html` : l'application s'ouvre dans votre navigateur. Aucune installation n'est nécessaire.

Les utilisateurs de Git peuvent aussi taper `git clone https://github.com/mikeDTA/broderieIA.git`.

## 3. Installer le projet sur GitHub

### Créer un compte
1. Allez sur github.com et cliquez sur **Sign up**.
2. Saisissez votre e-mail, un mot de passe et un pseudo, puis validez le code reçu par e-mail.

### Créer le dépôt
1. Cliquez sur le **+** en haut à droite, puis **New repository**.
2. Dans **Repository name**, tapez `broderieIA`.
3. Cochez **Public** (obligatoire pour la mise en ligne gratuite).
4. Cliquez sur **Create repository**.

### Déposer les fichiers et les dossiers
1. Sur la page du dépôt vide, cliquez sur le lien **uploading an existing file** (ou **Add file** puis **Upload files**).
2. Ouvrez le dossier du projet sur votre ordinateur et sélectionnez tout son contenu : `index.html`, `README.md`, `LICENSE`, `THIRD_PARTY.md`, `Dockerfile`, `docker-compose.yml`, `nginx.conf` et les dossiers `docs`, `scripts` et `models`. Si vous avez téléchargé l'IA de détourage (partie 49), ajoutez aussi le dossier `vendor`.
3. Faites glisser cette sélection dans la zone de la page GitHub. Les dossiers gardent leur contenu.
4. Attendez la fin du chargement, puis tapez dans la case en bas un message, par exemple « Première version ».
5. Cliquez sur le bouton vert **Commit changes**.

### Mettre le site en ligne (GitHub Pages)
1. Cliquez sur l'onglet **Settings** du dépôt, puis **Pages** dans le menu de gauche.
2. Sous **Build and deployment**, choisissez **Deploy from a branch**.
3. Pour **Branch**, choisissez `main` et `/ (root)`, puis **Save**.
4. Patientez une à deux minutes et rafraîchissez : l'adresse `https://mikeDTA.github.io/broderieIA/` apparaît en haut.

### Modifier plus tard
Refaites **Add file > Upload files** avec un fichier du même nom : il remplace l'ancien.

## 4. Démarrage rapide

![Écran d'accueil](img/01-accueil.png)

1. Cliquez sur **Choose File** (Choisir un fichier) à gauche et sélectionnez votre image : JPEG, PNG, SVG, GIF, WebP.
2. Le motif apparaît seul au centre. Les réglages par défaut conviennent à du coton avec un stabilisateur découpable.

![Motif généré après l'import : l'écran se lit de gauche à droite, réglages à gauche, aperçu au centre, fils en dessous](img/02-import.png)

Tout est visible sans faire défiler la page : les réglages à gauche (sur deux colonnes), l'aperçu et le montage au centre, la liste des fils en dessous. Les boutons **Réglages rapides** et **Tous les réglages** ouvrent un panneau qui **remplace la colonne de gauche** : l'aperçu, le nombre de points, la durée, les fils et le montage restent visibles à droite pendant que vous réglez. **Fermer** ramène la colonne de gauche.

3. Dans **Matière**, choisissez votre **Tissu** puis votre **Stabilisateur**. Le motif se recalcule : espacement des rangs et compensation de tirage changent.

![Choix du tissu (jersey)](img/03-tissu.png)

4. Les réglages de couleurs et de points s'ajustent seuls à votre image et au style choisi (partie 31).
4. Lisez la ligne grise sous l'aperçu : nombre de points, couleurs, coupes de fil, taille et durée estimée.
5. Lisez le bloc **Montage sur cadre et aiguille** tout en bas : il indique l'aiguille et la façon de tendre le tissu.
6. Cliquez sur **DST** pour télécharger `broderie.dst`, puis sur **EDR (couleurs)** pour `broderie.edr`.
7. Copiez le fichier DST ou 10O vers votre brodeuse de la façon habituelle (support lu par la machine, ou conversion par Embird).
8. Faites toujours un essai sur une chute du même tissu.

Pour une machine Toyota, cliquez plutôt sur **10O (Toyota)** : le format est décrit à la partie 20. Testez-le d'abord sur une chute.

## 5. Comprendre ce qui s'affiche

- **Points** : nombre de piqûres, sans compter les déplacements sans broder.
- **Coupes de fil** : nombre de fois où la machine devra couper. Moins il y en a, plus la broderie est propre.
- **Durée estimée** : points divisés par la vitesse, plus 1 minute par changement de couleur et 5 secondes par coupe. C'est une estimation : changez la **vitesse machine** dans les réglages pour l'ajuster à votre brodeuse.
- **Fils** : une ligne par aiguille, avec le nom du fil. Cliquez sur la case de couleur pour choisir la teinte exacte de votre bobine.

## 6. Les réglages rapides

Cliquez sur **Réglages rapides** : un panneau étroit remplace la colonne de gauche, et le motif reste visible à droite. Chaque réglage a un curseur à faire glisser et une case où taper une valeur. Cliquez sur **Fermer** pour le cacher.

![Panneau des réglages rapides](img/04-rapide.png)

- **Largeur (mm)** : taille finale du motif. La hauteur suit. Plage 20 à 300, défaut 100. Vérifiez qu'elle tient dans votre cadre.
- **Nombre de couleurs** : couleurs maximum après simplification de l'image. Plage 2 à 24, réglée seule selon votre image (de 6 à 15). Plus de couleurs donne un rendu plus fidèle, moins de couleurs donne moins de changements de fil. Au-delà de 15, la machine n'a plus assez d'aiguilles : un fil se change à la main.
- **Vitesse machine (points/min)** : sert uniquement à l'estimation du temps. Plage 200 à 1000, défaut 650.
- **Lissage des zones** : arrondit les contours et supprime le bruit. Plage 0 à 4, défaut 1. Montez si l'image est une photo, laissez à 0 pour un logo net.
- **Zone minimale fusionnée** : les taches plus petites que cette taille prennent la couleur voisine. Plage 0 à 300, défaut 30. Montez pour réduire fortement les coupes.
- **Distance sans coupe de fil** : si deux zones de même couleur sont plus proches que cette distance, la machine passe d'une zone à l'autre en brodant au lieu de couper. Plage 0 à 10 mm, défaut 3. Au-delà de 5 mm, des fils de liaison peuvent se voir.
- **Espacement des rangs** : écart entre deux lignes de points. Plus petit signifie plus dense. Plage 0,2 à 1,2 mm.
- **Longueur de point** : longueur d'un point dans les remplissages. Plage 1 à 7 mm, défaut 3,5.
- **Angle** : direction des lignes de remplissage. Changer d'angle entre deux zones donne du relief.
- **Compensation de tirage** : élargit les formes pour contrer le rétrécissement du tissu. Plage 0 à 1 mm. Montez sur les tissus extensibles.

## 7. Tous les réglages

Cliquez sur **Tous les réglages** (en bas à gauche) : un panneau affiche tous les réglages en quatre colonnes, rangés par famille. Le motif, les compteurs et les fils restent visibles à droite. Sur un petit écran, le bas de la liste peut défiler dans le panneau : utilisez la molette de la souris. Cliquez sur **Fermer** pour revenir.

![Panneau Tous les réglages : le motif reste visible à droite](img/05-avance.png)

En plus des réglages rapides :

- **Point minimum (mm)**, défaut 0,3 : un point plus court est ignoré, ce qui évite les paquets de fil.
- **Décalage des rangs** (1 à 6, défaut 3) : décale les piqûres d'une ligne à l'autre pour éviter les rainures visibles.
- **Espacement sous-couche** (1 à 5 mm, défaut 2,5) : écart entre les lignes de la sous-couche, la trame posée sous le remplissage pour le stabiliser.
- **Longueur point sous-couche** (1,5 à 5 mm, défaut 3).
- **Angle sous-couche relatif** (0 à 180°, défaut 90) : angle ajouté à celui du remplissage. 90° croise les deux couches.
- **Espacement satin** (0,2 à 0,8 mm, défaut 0,4) et **Longueur max satin** (2 à 12 mm, défaut 6).
- **Longueur point droit** (1 à 5 mm, défaut 2,5) pour les contours.
- **Espacement des hachures portrait** (0,5 à 3 mm, défaut 1).

Réglages ajoutés, inspirés d'Ink/Stitch :

- **Inverser le sens de départ** (0 ou 1) : le remplissage commence par l'autre côté. Équivalent : `flip`.
- **Variation aléatoire de longueur** (0 à 50 %) : rend les points moins réguliers pour éviter l'effet de rainures. Équivalent : `random_stitch_length_jitter_percent`.
- **Graine aléatoire** (1 à 99) : change le hasard du réglage précédent. Équivalent : `random_seed`.
- **Retrait de la sous-couche** (0 à 1,5 mm, défaut 0,3) : la sous-couche s'arrête un peu avant le bord. Équivalent : `fill_underlay_inset_mm`.
- **Passage central sous le satin** (0 ou 1, défaut 1) : une ligne de points droits est posée au milieu avant le satin. Équivalent : `center_walk_underlay`.
- **Répétitions du point de piqûre** (0 à 3) : chaque point droit est refait en aller-retour pour épaissir le trait. Équivalent : `bean_stitch_repeats`.
- **Répétitions du contour** (1 à 3) : le contour est brodé plusieurs fois. Équivalent : `repeats`.

Les cases du menu de gauche : **Ignorer le fond** (ne brode pas la couleur dominante des bords), **Sous-couche** (active ou non la trame).

## 8. Les types de point

Choisissez-les dans **Type de point** (menu de gauche).

- **Remplissage tatami** : rangées de points décalés qui couvrent une surface. Réglages : espacement des rangs, longueur de point, angle, décalage, compensation, sous-couche. Équivalents Ink/Stitch : `row_spacing_mm`, `max_stitch_length_mm`, `angle`, `staggers`, `pull_compensation_mm`, `fill_underlay`.
- **Satin le long des tracés** : le logiciel trouve la ligne centrale de chaque forme étroite et pose des points en travers, de bord à bord, comme un vrai satin. Réglages : espacement satin, longueur max satin, compensation de tirage. Il convient aux traits de moins de 6 mm de large.
- **Auto** : satin sur les tracés fins, tatami sur les surfaces larges, dans la même couleur.
- **Zigzag le long des tracés** : un zigzag de largeur fixe suit la ligne centrale de la forme. Il convient aux traits fins, aux broderies légères et aux contours décoratifs. Réglages : espacement des pointes et largeur (partie 28).
- **Point droit (contours)** : une ligne de points qui suit le bord des zones. Réglage : longueur du point droit. Équivalent Ink/Stitch : `running_stitch_length_mm`.
- **Tatami + contour** : remplissage puis ligne de contour par-dessus, qui rend les bords plus nets.

## 9. Couleur, niveaux de gris, noir et blanc

Le menu **Conversion** s'applique à toutes les images.

![Conversion en niveaux de gris](img/06-gris.png)

- **Couleur** : l'image est réduite au nombre de couleurs choisi.
- **Niveaux de gris** : l'image devient grise, avec autant de nuances que de couleurs, et les fils gris les plus proches sont choisis. Idéal pour une broderie sobre.
- **Noir et blanc** : deux tons seulement, donc très peu de changements de fil.

## 10. Le mode portrait

Cochez **Portrait (effet dessin à la main)**. L'image est découpée en tons, du plus sombre au plus clair : chaque ton est rempli de hachures, plus serrées pour les tons sombres, et le ton le plus clair est laissé libre, comme la feuille blanche d'un croquis. Vous pouvez utiliser jusqu'à 4 couleurs différentes (partie 41). Associez-le à **Niveaux de gris** ou **Noir et blanc** pour une version monochrome, ou à **Couleur** pour une version colorée.

![Mode portrait](img/08-portrait.png)

## 11. Ajouter des contours

![Tatami avec contours](img/07-contours.png)

Choisissez **Tatami + contour** : une ligne de point droit entoure chaque zone. Si le contour semble irrégulier, augmentez le lissage.

## 12. La palette de fils Madeira

La palette fournie est générique et étendue (77 couleurs : 12 teintes en 4 intensités, des gris, des beiges et des bruns). Pour utiliser Madeira :
1. Procurez-vous une palette Madeira au format **.gpl** (Ink/Stitch en propose) ou un fichier texte avec une ligne par fil : `code;nom;#rrggbb`.
2. Dans **Palette de fils**, cliquez sur **Importer Madeira**, puis choisissez le fichier.
3. Le nom du fichier et le nombre de fils s'affichent. Le motif se recalcule avec les fils les plus proches.

Je n'ai pas inclus la palette Madeira dans le projet : ses données de couleur ne sont pas libres de droits, et celles d'Ink/Stitch ont leur propre licence. Vérifiez les conditions du fichier que vous utilisez.

## 13. Réduire les coupes de fil sans perdre en qualité

1. Montez **Zone minimale fusionnée** (par exemple 60) : les petites taches disparaissent.
2. Montez **Lissage des zones** à 2.
3. Montez **Distance sans coupe de fil** à 4 ou 5 mm.
4. Baissez **Nombre de couleurs** si le motif reste chargé.
5. Regardez le compteur de coupes et l'aperçu après chaque changement.

## 14. Tissus, stabilisateurs et aiguilles

Choisissez le tissu : l'application règle le **stabilisateur dessous**, le **stabilisateur dessus** et l'aiguille. Vous pouvez changer les deux stabilisateurs à la main.

![Éponge : dessous découpable, dessus hydrosoluble](img/03-tissu.png)

- **Coton, popeline** : dessous découpable (ou déchirable), dessus inutile, aiguille 75/11 universelle, rangs à 0,40 mm.
- **Jersey, maille** : dessous découpable obligatoire, dessus facultatif si le motif est dense, aiguille 75/11 à bille, compensation 0,3 mm.
- **Polo piqué** : dessous découpable, dessus facultatif, aiguille 75/11 à bille.
- **Polaire** : dessous découpable, dessus hydrosoluble conseillé pour que les points ne s'enfoncent pas, aiguille 90/14.
- **Éponge, serviette** : dessous découpable, dessus hydrosoluble indispensable (les boucles avalent les points), aiguille 90/14.
- **Jean, toile épaisse** : dessous déchirable, dessus inutile, aiguille 90/14 jeans, rangs à 0,38 mm.
- **Feutrine** : dessous déchirable, dessus inutile, aiguille 80/12.
- **Satin, soie** : dessous découpable léger, dessus inutile, aiguille fine 65/9, rangs à 0,50 mm.
- **Cuir, simili** : dessous déchirable, dessus inutile, aiguille 90/14 cuir, rangs à 0,50 mm.

Découpable : on découpe l'excédent autour du motif, il reste sous la broderie. Déchirable : on le déchire. Hydrosoluble : il se dissout à l'eau.

## 15. Si quelque chose ne va pas

- **L'image ne s'affiche pas** : essayez un autre fichier ou convertissez-la en PNG.
- **Trop de coupes de fil** : suivez la partie 13.
- **Les formes se déforment dans la couture** : augmentez la compensation de tirage et vérifiez le stabilisateur.
- **Le fichier ne s'ouvre pas sur la machine** : ouvrez-le d'abord dans Embird pour le convertir.
- **La colonne à rails ne s'affiche pas** : chaque rail demande au moins deux points. Recommencez avec **Satin à rails**.
- **Le remplissage guidé ne change rien** : tracez d'abord la **Ligne guide** (au moins deux points), puis **Terminer la ligne**.
- **La police importée n'apparaît pas** : utilisez un fichier `.ttf`, `.otf` ou `.woff`.
- **Le panneau de réglages a remplacé la colonne de gauche** : c'est voulu, pour ne rien cacher du motif. Cliquez sur **Fermer** pour retrouver le tissu, le style et les exports.
- **Docker dit « permission denied »** : fermez votre session Kubuntu et rouvrez-la après la commande `usermod`, ou lancez les commandes précédées de `sudo`.
- **Docker dit que le port 8080 est déjà pris** : dans `docker-compose.yml`, remplacez `"8080:80"` par `"8081:80"`, puis relancez `docker compose up -d`, et ouvrez `http://localhost:8081`.

## 16. Broder du texte

1. Dans la zone **Texte** à gauche, tapez votre texte, par exemple un prénom.
2. Choisissez une **Police** : sans empattement, avec empattement, machine à écrire ou écriture manuscrite. Ces polices sont celles de votre ordinateur, elles peuvent donc varier d'un appareil à l'autre.
3. Cliquez sur **Broder ce texte**. L'application passe seule en noir et blanc avec le point satin le long des tracés.
4. Changez la couleur du fil dans la liste **Fils** si vous voulez une autre teinte.

![Texte brodé](img/09-texte.png)

Le texte est transformé en image puis brodé : l'application ne reconnaît pas l'écriture d'une photo. Les petites lettres (moins de 8 mm de haut) ne sont pas recommandées.

## 17. Le rendu relief 3D

1. Cochez **Rendu relief 3D** dans la zone **Affichage**.
2. Faites glisser **Direction de la lumière** : chaque point s'éclaire selon son angle, comme un vrai fil.
3. Faites glisser **Inclinaison de la vue** pour pencher l'aperçu en perspective.

![Rendu relief](img/10-relief.png)

C'est un rendu simulé en deux dimensions avec ombres et reflets, pas un modèle 3D que l'on peut faire tourner.

## 18. Brodeuse à 15 aiguilles

1. Le **Nombre de couleurs** va jusqu'à 15, soit une couleur par aiguille.
2. Sous l'aperçu, la liste **Fils** a une ligne par couleur de fil, donc par aiguille : deux zones de même couleur sont regroupées sur la même aiguille, ce qui évite des changements de fil inutiles. La liste a une ligne par aiguille, de « Aiguille 1/15 » à « Aiguille 15/15 ». L'ordre suit l'ordre de broderie : la première couleur brodée est l'aiguille 1.
3. Dans chaque ligne, ouvrez le menu déroulant pour choisir un fil de la palette, ou cliquez sur la case de couleur pour une teinte libre.
4. L'aperçu change tout de suite. Les fils de la palette importée (Madeira) apparaissent dans ces menus.

![Choix des fils par aiguille](img/11-aiguilles.png)

Les fichiers ne contiennent pas le numéro d'aiguille : après le chargement, vérifiez sur la machine que chaque couleur est bien associée à l'aiguille voulue.

## 19. Un style de point par couleur

1. Cliquez sur une zone de l'image : la ligne du fil correspondant s'entoure en orange dans la liste **Fils**.
2. Dans cette ligne, à droite de la case de couleur, le menu choisit le **style de point** : Tatami, Satin, Auto, Point droit ou Tatami + contour.
3. La petite case numérique à droite règle l'**angle** des points de cette couleur seulement.
4. L'aperçu, le nombre de points et la durée sont recalculés tout de suite.

![Style de point choisi par couleur](img/12-style-couleur.png)

Le menu **Type de point** à gauche donne le style par défaut : le changer remet toutes les couleurs sur ce style.

Si vous donnez à une zone la même couleur de fil qu'une autre, elles sont fusionnées sur la même aiguille.

## 20. Le vrai satin et la reconnaissance d'écriture

Le satin est calculé le long de la ligne centrale des formes étroites. Il rend bien les lettres et les traits réguliers, et les jonctions entre traits (milieu d'un « a », liaison d'un « m ») peuvent montrer des points qui se croisent : vérifiez l'aperçu en **rendu relief**.

![Texte en satin](img/13-satin.png)

Pour broder automatiquement l'écriture d'une image en satin :
1. Importez l'image qui contient du texte.
2. Cliquez sur **Détecter l'écriture (OCR)**. Une connexion internet est nécessaire, car la bibliothèque de reconnaissance est chargée à ce moment.
3. Le message sous le bouton indique le nombre de mots reconnus. Les zones de texte sont brodées en satin, le reste garde son style.

Si le message dit que la reconnaissance est impossible, vérifiez votre connexion et recommencez. À défaut, choisissez le style **Auto** : les tracés fins sont brodés en satin sans reconnaissance.

## 21. La vue 3D tournante

1. Cochez **Vue 3D tournante (three.js)** dans la zone **Affichage**. Une connexion internet est nécessaire la première fois, car la bibliothèque three.js est chargée depuis cdnjs.
2. Maintenez le clic et glissez pour faire tourner et pencher la broderie. La molette zoome.
3. Décochez **Rotation automatique** pour arrêter le tour continu.
4. Pour profiter de la carte graphique, voir la partie 30. Si la vue ne s'affiche pas, décochez la case, vérifiez votre connexion, puis recommencez.

Chaque point est un petit bloc éclairé, avec la couleur du fil choisi pour l'aiguille.

## 22. Les formats d'export

- **DST** : format Tajima, le plus répandu. Il contient les points, les sauts et les changements de couleur.
- **10O (Toyota)** : écrit d'après la structure d'un fichier 10O réel. Il contient les points, les sauts et les changements de couleur, sur des blocs de 512 octets. Le fichier de couleurs séparé (`.00o`) n'est pas généré : utilisez l'EDR ou réglez les fils sur la machine. Ce format n'a pas été essayé sur une brodeuse : faites un test sur une chute.
- **EDR** : la liste des couleurs de fils.
- **EOF** : c'est le fichier de projet vectoriel d'Embird Studio, sans description publique. Il n'est pas disponible. Ouvrez le DST dans Embird pour continuer à le modifier.

## 24. Faire correspondre les couleurs de l'image et du fil

1. Dans la liste **Fils**, chaque ligne commence par un carré : la couleur moyenne de la zone **dans l'image**. Il est suivi d'une pastille : la couleur du **fil** retenu.
2. Le fil est choisi comme l'œil le verrait (calcul en espace colorimétrique Lab), pas par simple addition de rouge, vert et bleu.
3. Si le fil proposé ne vous convient pas, choisissez-en un autre dans le menu déroulant de la ligne, ou cliquez sur la case de couleur.
4. Plus la palette est riche, plus la correspondance est fidèle : importez la palette Madeira (partie 12) pour retrouver vos références de bobines. La palette générique contient déjà 77 couleurs, ce qui donne des teintes proches de l'image.

## 25. Ajouter un texte sur l'image brodée

Le texte sur l'image se règle maintenant dans un panneau à part, qui permet **plusieurs textes avec des polices différentes** : voir la partie 46. Les points de l'image sont retirés sous chaque lettre, avec une petite marge : les fils ne se superposent pas.

![Texte sur l'image](img/14-texte-image.png)

## 26. Mettre l'application sur un serveur (Kubuntu, Docker)

L'application n'a besoin que d'un **serveur web** : pas de base de données, pas de PHP. Docker installe ce serveur (nginx) pour vous.

![Comment le navigateur parle au conteneur](img/26-schema-docker.png)

 Les captures d'écran de cette partie n'ont pas pu être faites sur Kubuntu : les commandes sont donc données en entier, à copier.

### Étape 1 : ouvrir le terminal
1. Cliquez sur le menu en bas à gauche, ou tapez sur la touche Windows de votre clavier.
2. Écrivez « Konsole » et cliquez sur l'application. Vous pouvez aussi appuyer sur Ctrl + Alt + T.
3. Une fenêtre noire s'ouvre : c'est là que vous collez les commandes. Collez avec Ctrl + Maj + V, puis Entrée.

### Étape 2 : installer Docker
Collez les commandes une par une. Le mot de passe de votre session est demandé : rien ne s'affiche pendant la saisie, c'est normal.

```
sudo apt update
sudo apt install -y ca-certificates curl git
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
```

Puis, en une seule commande :

```
echo "deb [arch=$(dpkg --print-architecture) \
signed-by=/etc/apt/keyrings/docker.asc] \
https://download.docker.com/linux/ubuntu \
$(. /etc/os-release && echo ${UBUNTU_CODENAME:-$VERSION_CODENAME}) stable" \
| sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io \
  docker-buildx-plugin docker-compose-plugin
```

Autorisez votre compte à utiliser Docker, puis **fermez votre session et rouvrez-la** :

```
sudo usermod -aG docker $USER
```

Vérifiez l'installation avec ces deux commandes : chacune doit afficher un numéro de version.

```
docker --version
docker compose version
```

### Étape 3 : récupérer le projet
```
cd ~
git clone https://github.com/mikeDTA/broderieIA.git
cd broderieIA
ls
```
La liste doit contenir `Dockerfile`, `docker-compose.yml`, `nginx.conf`, `index.html` et `docs`. Sans Git, téléchargez le ZIP depuis GitHub (partie 2), décompressez-le et placez-vous dans le dossier avec la commande `cd`.

### Étape 4 : les fichiers Docker (déjà dans le projet)
**Dockerfile** (version 2.5.1) : décrit la boîte en deux étapes. La première télécharge l'IA de détourage (facultative), la seconde installe le serveur web nginx avec l'application et un contrôle de santé automatique.

```
FROM alpine:3.20 AS ai
ARG WITH_AI=1
RUN apk add --no-cache curl
COPY scripts/download-ai.sh /ai/download-ai.sh
RUN mkdir -p /out/models /out/vendor/ort && \
    if [ "$WITH_AI" = "1" ]; then \
      sh /ai/download-ai.sh /out || echo "IA non telechargee"; fi

FROM nginx:stable-alpine
ARG APP_VERSION=2.5.1
COPY nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=ai /out/ /usr/share/nginx/html/
COPY index.html /usr/share/nginx/html/index.html
COPY docs /usr/share/nginx/html/docs
HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
  CMD wget -qO- http://127.0.0.1/ >/dev/null || exit 1
EXPOSE 80
```

Si la construction n'a pas accès à internet, l'étape IA échoue sans bloquer : l'application fonctionne, seul le détourage par IA est absent.

**docker-compose.yml** : donne le nom de la boîte (`broderieia`), sa version (2.5.1), son port (8080), le choix d'installer l'IA (`WITH_AI`, mettez `"0"` pour ne pas la télécharger), une protection contre les élévations de droits et le redémarrage automatique.

```
services:
  broderieia:
    build:
      context: .
      args:
        APP_VERSION: "2.5.1"
        WITH_AI: "1"
    image: broderieia:2.5.1
    container_name: broderieia
    ports:
      - "8080:80"
    security_opt:
      - no-new-privileges:true
    restart: unless-stopped
```

**nginx.conf** : réglages du serveur web (compression, en-têtes de sécurité, version du serveur masquée, page principale toujours rechargée, images du guide, modèle d'IA et fichiers `.wasm` mis en cache).

```
server {
    listen 80;
    server_name _;
    server_tokens off;
    root /usr/share/nginx/html;
    index index.html;
    gzip on;
    location = /index.html {
        add_header Cache-Control "no-cache";
    }
    location ~* \.wasm$ {
        default_type application/wasm;
        expires 30d;
    }
    location / { try_files $uri $uri/ =404; }
}
```

Pour modifier un de ces fichiers, ouvrez-le avec l'éditeur **Kate** (clic droit sur le fichier, puis Ouvrir avec Kate).

### Étape 5 : démarrer
```
docker compose up -d --build
docker ps
```
La deuxième commande doit afficher une ligne `broderieia` avec l'état « Up ». Après une trentaine de secondes, l'état devient « Up (healthy) » : le contrôle de santé confirme que le serveur répond. Ouvrez Firefox et allez sur `http://localhost:8080` : l'application apparaît, comme sur la capture de la partie 4.

### Étape 6 : l'ouvrir depuis un autre ordinateur
1. Sur le serveur, tapez `hostname -I` : la première adresse (par exemple `192.5.168.1.20`) est celle du serveur.
2. Sur l'autre ordinateur, allez sur `http://192.5.168.1.20:8080`.
3. Si la page ne s'ouvre pas, autorisez le port : `sudo ufw allow 8080/tcp` (le pare-feu est inactif par défaut sous Kubuntu : `sudo ufw status` le dit).

### Étape 7 : gérer le service
- Voir la version installée : `docker images` (la ligne `broderieia` doit afficher `2.5.1`).
- Voir les messages : `docker compose logs -f` (Ctrl + C pour quitter).
- Arrêter : `docker compose down`.
- Mettre à jour le conteneur après un changement sur GitHub :

```
cd ~/broderieIA
git pull
docker compose up -d --build
docker image prune -f
docker compose ps
```

La première commande entre dans le dossier, la deuxième récupère la nouvelle version, la troisième reconstruit et relance la boîte, la quatrième supprime les anciennes versions inutiles, la dernière montre l'état (cherchez « healthy »).

![Les quatre étapes de la mise à jour](img/27-schema-mise-a-jour.png)

- Au redémarrage du serveur, l'application repart seule grâce à `restart: unless-stopped`.

### Sans Docker : nginx seul
```
sudo apt update
sudo apt install -y nginx
sudo cp -r index.html docs /var/www/html/
```
Ouvrez `http://localhost` dans Firefox. Pour mettre à jour, recopiez les fichiers avec la dernière commande.

### Avec un nom de domaine et le HTTPS
Une fois l'application en ligne, achetez un nom de domaine, faites-le pointer vers l'adresse IP publique du serveur, puis, avec la version nginx seul :

```
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d votre-domaine.fr
```

Attention : la vue 3D et la reconnaissance d'écriture chargent des bibliothèques depuis internet. Un serveur sans accès à internet ne peut pas les utiliser, et rien d'autre n'est affecté.

## 27. Les réglages de chaque aiguille (15 couleurs)

Chaque couleur de fil, donc chaque aiguille, peut avoir ses propres réglages de points.

1. Dans la liste **Fils**, repérez la ligne de l'aiguille voulue. Elle contient le style (tatami, satin, zigzag…), l'angle et un bouton **⚙**.
2. Cliquez sur **⚙** : un panneau s'ouvre à la place de la colonne de gauche, avec les réglages de points de cette aiguille uniquement, rangés par famille. Le motif et les fils restent visibles à droite.
3. Déplacez un curseur, tapez une valeur ou choisissez dans un menu : seule cette aiguille change. Le motif se recalcule après un court instant.
4. **Réinitialiser** remet l'aiguille sur les réglages généraux. **Copier vers toutes les aiguilles** applique ses réglages aux 15 couleurs. **Fermer** ferme le panneau.

![Réglages de l'aiguille 1](img/15-reglages-aiguille.png)

Les réglages généraux (largeur, nombre de couleurs, vitesse, simplification) restent communs à toutes les aiguilles. Les réglages d'une aiguille sont conservés tant que sa couleur de fil ne change pas.

## 28. Zigzag, sous-couches et méthodes de remplissage

### Le point zigzag
Choisissez **Zigzag le long des tracés** dans **Type de point** (ou dans la ligne d'une aiguille). Réglez dans « Tous les réglages » ou dans **⚙** : l'**espacement des pointes** (0,2 à 3 mm) et la **largeur du zigzag** (0,5 à 8 mm).

![Texte en zigzag](img/16-zigzag.png)

### Les sous-couches du satin
La sous-couche est une trame posée sous le satin pour le soutenir. Le réglage **Sous-couche du satin** propose :
- **Aucune** ;
- **Contour** : une ligne de points suit le bord de la forme, à l'intérieur. Réglages : retrait (0 à 2 mm) et longueur de point (1 à 4 mm) ;
- **Zigzag** : un zigzag espacé couvre la largeur. Réglages : espacement (1 à 6 mm) et retrait (0 à 2 mm) ;
- **Contour + zigzag** : les deux.

Le **passage central** (partie 7) s'ajoute à ces choix.

### Les méthodes de remplissage
Le réglage **Méthode de remplissage** change la façon dont une surface est couverte :
- **Rangées (tatami)** : des lignes parallèles, la méthode habituelle.
- **Contours concentriques** : des anneaux qui suivent le bord et se resserrent vers le centre.
- **Cercles** : des cercles autour du centre de la zone.
- **Méandre ondulé** : des rangées ondulées. Réglez l'**amplitude** (0,2 à 5 mm) et la **longueur d'onde** (4 à 40 mm).

![Contours concentriques](img/17-contours-concentriques.png)

![Cercles](img/18-cercles.png)

![Méandre ondulé](img/19-meandre.png)

Les remplissages en contours et en cercles sont plus décoratifs que les rangées : essayez-les sur une chute avant de broder, car ils donnent plus de coupes de fil.

## 29. Départ, arrivée et points d'arrêt

Dans « Tous les réglages » ou dans **⚙**, la famille **Départ, arrivée, arrêts** contient :
- **Point de départ** : Automatique, ou un coin de la broderie (haut gauche, haut droite, bas gauche, bas droite) ou le centre. L'aiguille commence près de ce point et enchaîne ses zones en limitant les sauts.
- **Point d'arrivée** : même choix. La dernière zone brodée par cette aiguille est celle qui est la plus proche de ce point, utile pour finir près de l'endroit où l'on changera de fil.
- **Points d'arrêt** : Oui ajoute trois petits points avant et après chaque zone, qui fixent le fil quand la machine ne le fait pas elle-même.

## 30. La carte graphique et le rendu 3D

La vue 3D utilise la carte graphique (WebGL) pour afficher chaque fil en relief, avec ombres et éclairage.

1. Cochez **Vue 3D tournante**, puis laissez **Haute qualité (ombres, carte graphique)** cochée.
2. Sous la case, la ligne **Carte graphique** donne le nom de la carte utilisée.
3. Si ce nom contient « SwiftShader », « llvmpipe » ou « software », le navigateur n'utilise pas votre carte : l'affichage sera lent. Activez l'accélération matérielle :
   - Chrome : menu (trois points), **Paramètres**, **Système**, **Utiliser l'accélération matérielle lorsqu'elle est disponible**, puis relancez ;
   - Firefox : **Paramètres**, **Général**, **Performances**, décochez les paramètres recommandés, cochez **Utiliser l'accélération matérielle lorsque disponible**, puis relancez ;
   - Kubuntu : ouvrez **Configuration du système**, puis **Pilotes supplémentaires** (ou « Driver Manager ») pour installer le pilote de votre carte NVIDIA ou AMD.
4. Si l'écran saccade encore, décochez **Haute qualité** : les ombres sont désactivées et le rendu s'allège.

Les chaînes de menus peuvent varier selon la version de votre navigateur.

## 31. Optimisation automatique des réglages selon le style

À chaque changement de **Conversion** (couleur, niveaux de gris, noir et blanc), de **Type de point** ou du mode **Portrait**, l'application règle seule le nombre de couleurs, le lissage, la fusion des petites zones et les réglages de points les plus adaptés. Elle regarde aussi votre image : une image simple (logo, dessin) garde ses détails, une image très détaillée (photo) est simplifiée davantage.

![Réglages optimisés après le passage en noir et blanc](img/20-optimisation.png)

1. Importez une image : les réglages sont optimisés tout de suite.
2. Changez de style : la phrase sous la case **Optimiser les réglages à chaque changement de style** dit ce qui a été réglé (par exemple « noir et blanc, tatami · image simple »).
3. Les curseurs de **Réglages rapides** et de **Tous les réglages** montrent les nouvelles valeurs, que vous pouvez retoucher ensuite.
4. Pour garder vos propres valeurs, décochez la case avant de changer de style.

Ce qui change selon le style :
- **Couleur** : de 6 à 15 couleurs selon le nombre de teintes de l'image. **Niveaux de gris** : de 5 à 10 nuances. **Noir et blanc** : 2 tons, lissage plus fort, zones fusionnées plus grandes.
- **Satin et Auto** : 4 couleurs, lissage 2, grandes zones fusionnées, sous-couche de contour.
- **Zigzag** : 3 couleurs, pointes espacées de 1 mm, largeur 2,5 mm.
- **Point droit** : 4 couleurs, points de 2,5 mm.
- **Portrait** : jusqu'à 4 couleurs (partie 41), lissage 2, hachures de 1 mm.

L'espacement des rangs dépend du tissu choisi, pas du style : il n'est pas modifié ici.

## 32. Autres réglages d'Ink/Stitch

Dans « Tous les réglages » et dans le **⚙** de chaque aiguille :
- **Réduction aléatoire de la largeur du satin** (0 à 50 %) : raccourcit certains points du satin pour un aspect moins régulier. Équivalent : `random_width_decrease_percent`.
- **Compensation de tirage du satin** (0 à 30 % de la largeur) : élargit le satin proportionnellement à sa largeur. Équivalent : `pull_compensation_percent`.
- **Points courts à l'intérieur des courbes** (0 à 50 %) : un point sur deux est raccourci pour éviter l'accumulation de fil dans les virages. Équivalent : `short_stitch_inset_percent`.
- **Couper le fil après chaque zone** (Non ou Oui) : chaque zone de cette aiguille est suivie d'une coupe, sans fusion des sauts courts. Équivalent : `trim_after`.

Le bouton **Point guide des cercles** (zone **Style**) sert à placer le centre des cercles où vous voulez :
1. Choisissez la méthode de remplissage **Cercles**.
2. Cliquez sur **Point guide des cercles**.
3. Cliquez sur l'aperçu à l'endroit voulu : les cercles se redessinent autour de ce point.

![Cercles autour d'un point guide](img/21-point-guide.png)

Trois polices de plus sont proposées pour le texte : gras compact, classique et large lisible.

## 33. Importer une police pour le texte

Les polices d'Ink/Stitch sont des fichiers de dessin à part, propres à Ink/Stitch, que cette application ne peut pas lire. À la place, vous pouvez importer **n'importe quelle police d'ordinateur** (fichiers `.ttf`, `.otf`, `.woff`) : elle sert au texte seul et au texte sur l'image.

1. Téléchargez une police gratuite, par exemple sur le site Google Fonts, et décompressez le fichier reçu.
2. Dans la zone **Texte seul**, cliquez sur **Importer une police** et choisissez le fichier `.ttf` ou `.otf`.
3. La police apparaît dans le menu **Police** et se sélectionne seule. Si un texte est déjà tapé, il est brodé tout de suite.

![Texte brodé avec une police importée](img/24-police-importee.png)

Choisissez une police aux traits **fins ou moyens** : les polices très grasses donnent des lettres trop larges pour le satin (au-delà de 6 mm de trait, le satin se fractionne et perd son aspect). Pour les gros caractères, utilisez le style **Auto** ou le tatami.

## 34. La colonne de satin à rails

Une colonne de satin à rails est une bande de satin que vous dessinez vous-même : deux lignes (les rails) la bordent, et les points vont d'un rail à l'autre. C'est idéal pour une bordure, une tige ou un lettrage dessiné à la main.

1. Importez une image (la colonne se dessine par-dessus).
2. Dans la zone **Style**, cliquez sur **Satin à rails**.
3. Cliquez sur l'aperçu pour poser les points du **rail 1**, du début à la fin de la bande. Un clic = un point, les points se relient en orange.
4. Cliquez sur **Rail suivant**, puis posez les points du **rail 2** dans le même sens.
5. Cliquez sur **Terminer la colonne** : le satin apparaît, et une ligne « rails » s'ajoute dans la liste des fils pour choisir sa couleur.
6. Répétez pour d'autres colonnes. **Effacer** supprime tous les tracés.

![Une colonne de satin à rails (en rouge, en bas à gauche)](img/23-satin-rails.png)

Pour une bande régulière, posez le même nombre de points sur les deux rails et dans le même sens. Les réglages **espacement satin**, **longueur max satin**, **compensation de tirage**, **passage central** et **sous-couches du satin** s'appliquent aussi aux colonnes à rails.

## 35. Le remplissage guidé par une ligne

Avec le remplissage guidé, les rangées de points suivent une ligne que vous tracez, au lieu d'être droites : on obtient des courbes qui épousent la forme (un pétale, un tissu qui se plie).

1. Importez une image.
2. Dans la zone **Style**, cliquez sur **Ligne guide**.
3. Cliquez sur l'aperçu pour poser les points de la ligne : une ligne bleu-vert apparaît. Placez-la à travers la zone à remplir.
4. Cliquez sur **Terminer la ligne**. La méthode de remplissage **Guidé par une ligne** se choisit seule et les rangées suivent la ligne.

![Rangées qui suivent la ligne guide (en bleu-vert)](img/22-ligne-guide.png)

Les rangées sont parallèles à la ligne, de chaque côté, et se décalent comme les rangées du tatami. Le remplissage guidé crée beaucoup de coupes de fil : surveillez le compteur et augmentez la **distance sans coupe de fil** si besoin. Pour revenir aux rangées droites, choisissez **Rangées (tatami)** dans **Méthode de remplissage**.

## 36. La sous-couche en zigzag du tatami

La sous-couche du tatami peut maintenant être faite en zigzag, ce qui soutient mieux les grandes surfaces sur les tissus souples.

1. Ouvrez **Tous les réglages**, famille **Sous-couche**.
2. Réglez **Type de sous-couche du tatami** sur **Zigzag**. Les réglages **Espacement sous-couche en zigzag** et **Retrait de la sous-couche** s'appliquent. L'**espacement sous-couche** donne l'écart entre deux rangées de zigzag.
3. Pour la voir, choisissez un grand espacement des rangs : la sous-couche n'est visible que si le remplissage du dessus est lâche.

![Sous-couche en zigzag sous un remplissage espacé](img/25-sous-couche-zigzag.png)

## 37. Se repérer : couleurs, icônes et panneaux

L'interface est colorée pour que chaque zone se reconnaisse d'un coup d'œil. Chaque titre porte une icône :
- 🧵 **Matière** : tissu et stabilisateurs (dessous et dessus).
- 🎨 **Style** : conversion, type de point, optimisation automatique, tracés à la main.
- ✍️ **Texte seul** et 🔤 **Texte sur l'image**.
- 🌈 **Palette de fils** : import de la palette Madeira.
- 👁️ **Affichage** : relief, vue 3D, lumière, inclinaison.
- 💾 **Exporter** : DST (bouton orange), 10O et EDR.
- 📐 **Montage sur cadre et aiguille** et 🪡 **Fils**, à droite de la colonne de gauche.
- ✏️ **Corriger** et 🤖 **IA** : une deuxième barre sous la barre de zoom (parties 48 et 49).

![Écran d'accueil : glissez une image dans le cadre en pointillés](img/01-accueil.png)

**Glisser-déposer** : vous pouvez faire glisser une image depuis votre dossier directement sur la page, sans passer par le bouton de choix de fichier.

**Aide au survol** : laissez la souris sur un bouton quelques secondes, une bulle explique à quoi il sert.

**Panneaux** : les trois panneaux (**Réglages rapides**, réglages d'une aiguille avec **⚙**, **Tous les réglages**) remplacent la colonne de gauche au lieu de se poser par-dessus. Ainsi, rien ne cache le motif, la ligne grise de compteurs, la liste des fils ni le montage. Pour changer de tissu ou de style pendant qu'un panneau est ouvert, cliquez sur **Fermer**. Dans **Réglages rapides**, le bouton **Tous les réglages** passe directement au panneau complet.

![Réglages rapides : le motif, les compteurs et les fils restent visibles](img/04-rapide.png)

**Thème clair ou sombre** : l'application suit le réglage de votre ordinateur. Les couleurs vives (violet, orange, turquoise) restent identiques dans les deux thèmes.

![Le thème sombre avec le panneau Tous les réglages](img/28-theme-sombre.png)

## 38. Redimensionner votre motif

Une barre **Taille du motif** se trouve juste au-dessus de la photo : elle règle la taille finale de la broderie.

![La barre Taille du motif au-dessus de l'aperçu](img/30-redimensionner.png)

1. Déplacez le curseur, ou tapez la **largeur** en millimètres dans la première case. La hauteur se calcule seule.
2. Vous préférez fixer la hauteur ? Tapez-la dans la deuxième case : la largeur s'adapte en gardant les proportions de l'image.
3. Le motif se recalcule à la nouvelle taille. Le nombre de points, la durée et le montage se mettent à jour.

La largeur va de 20 à 300 mm. Vérifiez que la taille choisie tient dans le cadre de votre brodeuse. Ce réglage est le même que **Largeur** dans les réglages rapides.

## 39. Plus de couleurs et ajout de couleurs

La conversion d'une photo utilise maintenant plus de couleurs : l'application compte les teintes de votre image et choisit entre 6 et 15 couleurs. La palette de fils proposée compte 77 couleurs.

1. Ouvrez **Réglages rapides**.
2. Cliquez sur **➕ Ajouter une couleur** pour en ajouter une, ou sur **➖ Retirer** pour en enlever une. Le motif est recalculé à chaque clic. Le curseur **Nombre de couleurs** fait la même chose.
3. La ligne grise de compteurs indique le nombre de couleurs réellement brodées. Deux zones qui reçoivent le même fil sont regroupées sur la même aiguille.

![Réglages rapides avec les boutons Ajouter une couleur et Retirer](img/31-plus-de-couleurs.png)

Votre brodeuse a 15 aiguilles. Si le motif dépasse 15 couleurs, la ligne de compteurs affiche un avertissement : il faudra changer un fil à la main en cours de broderie.

## 40. Une conversion de meilleure qualité

L'application a été essayée sur trois photos libres de droits (un portrait, un chat et une tasse de café). L'écart moyen entre les couleurs de la photo et celles des fils a été mesuré avant et après les améliorations : il baisse de **57 %** sur le portrait, de **34 %** sur le chat et de **48 %** sur la tasse. Les gains viennent de :
- **Calcul des couleurs à la manière de l'œil** : les couleurs sont regroupées dans un espace colorimétrique proche de la vision humaine (Lab), pas par simple addition de rouge, vert et bleu.
- **Palette plus riche** : 77 fils au lieu de 18.
- **Plus de couleurs** : jusqu'à 15 adaptées à l'image.
- **Lissage de la photo avant conversion** : le grain de l'image est atténué en gardant les contours.
- **Image plus fine** : l'image est analysée en plus haute résolution.
- **Angle automatique** : les rangées de points suivent la forme de chaque zone.

![Avant : ancienne conversion. Après : nouvelle conversion](img/34-qualite-avant-apres.png)

Réglages de la famille **Qualité de la photo** (dans les réglages rapides et dans « Tous les réglages ») :
- **Lissage de la photo avant conversion** (0 à 3, défaut 1) : plus la valeur monte, plus le grain disparaît. Montez pour une photo bruitée, laissez à 0 pour un logo net.
- **Saturation des couleurs** (0 à 60 %, défaut 10) : rend les couleurs plus vives, car un fil paraît souvent plus terne qu'un écran.
- **Contraste automatique** (Non ou Oui) : étire les clairs et les sombres d'une photo grise ou délavée.
- **Angle automatique par zone** (Non ou Oui, défaut Oui) : chaque zone reçoit un angle de rangées qui suit sa forme. Si vous tapez un angle dans la ligne d'une aiguille, cette zone garde votre angle.

## 41. Le portrait : jusqu'à 4 couleurs et du texte

1. Cochez **Portrait (effet dessin)**.
2. Réglez **Couleurs du portrait (1 à 4)** dans les réglages rapides. Chaque couleur correspond à un ton de l'image, du plus sombre au plus clair. Les tons sombres sont hachurés plus serré.
3. Avec **Couleur**, les fils sont choisis d'après les tons de la photo. Avec **Noir et blanc** ou **Niveaux de gris**, ce sont des noirs et des gris.

![Portrait avec 4 couleurs de fils](img/32-portrait-4-couleurs.png)

Le texte sur la photo marche aussi en portrait (partie 46) :
1. Cliquez sur **Gérer les textes**, puis **Ajouter un texte**.
2. Tapez le texte, puis réglez la taille et la position.
3. Les hachures sont retirées sous les lettres, avec une petite marge, et le texte est brodé par-dessus.
4. Chaque texte a sa ligne « texte » dans la liste des fils.

![Portrait avec un texte en bas](img/33-portrait-texte.png)

Utilisez une photo où le visage est bien contrasté : un portrait flou ou en contre-jour donne des tons peu lisibles. Le résultat est un croquis hachuré, pas une photo.

## 42. Fermer une forme

Un cercle ou un contour dessiné avec un petit trou donne une forme ouverte : les points débordent ou la forme se découpe mal. Deux outils la referment.

![Avant : le cercle est ouvert. Après : le trou est fermé](img/39-fermer-forme.png)

**Fermeture automatique** : le réglage **Fermeture des petits trous (mm)** (réglages rapides, de 0 à 3 mm, défaut 0,5) comble les trous des formes. Il ferme les trous jusqu'à environ le double de la valeur : à 1,2 mm, un trou de 2 mm disparaît.

**Fermeture à la main**, directement sur l'image :
1. Dans la zone **Style**, cliquez sur **Fermer une forme**.
2. Cliquez d'un côté du trou, puis de l'autre côté. Deux clics suffisent.
3. Un pont de la couleur de la forme est ajouté entre les deux points, et le motif est recalculé.
4. Si le pont est trop fin ou trop épais, réglez **Épaisseur de la fermeture manuelle** (0,4 à 3 mm) dans « Tous les réglages ».

Le bouton **Effacer** retire les fermetures à la main (ainsi que la ligne guide, le point guide et les rails).

## 43. Regrouper les couleurs pour limiter les sauts et les coupes de fil

Chaque coupe de fil laisse un bout de fil à rattraper et rallonge la broderie. L'application réduit les coupes de trois façons, réglables dans « Simplification (moins de coupes) » :

- **Fusionner les fils proches** (0 à 30, défaut 8) : deux couleurs presque identiques reçoivent le même fil, donc la même aiguille. Montez la valeur pour avoir moins de changements de fil.
- **Optimiser l'ordre des zones** (Oui) : les morceaux d'une même couleur sont brodés du plus proche au plus proche, au lieu de sauter d'un bout à l'autre de l'image.
- **Liaison sans coupe dans une même couleur** (0 à 40 mm, défaut 20) : quand deux morceaux d'une même couleur sont reliés par un passage qui reste dans la zone de cette couleur, la machine y passe en brodant de petits points au lieu de couper.

![Avant et après le regroupement](img/41-regroupement.png)

Sur les trois photos d'essai, le nombre de coupes de fil passe de 2 638 à 332 (portrait), de 2 210 à 180 (chat) et de 1 741 à 184 (tasse), soit 87 à 92 % de coupes en moins.

Les petits points de liaison sont posés dans la zone de la même couleur : sur une couleur très claire, ils peuvent se voir un peu. Baissez alors la distance de liaison. Pour une aiguille précise, **Couper le fil après chaque zone** (⚙ de l'aiguille) remet les coupes.

## 44. Zoom et agrandissement de la photo

Une barre de zoom se trouve juste au-dessus de la photo.

![Zoom à 231 % sur la tasse : les détails des points apparaissent](img/35-zoom.png)

- **🔍+** et **🔍−** : zoom avant et arrière. La molette de la souris fait la même chose, autour de l'endroit pointé.
- Quand le zoom dépasse 100 %, **faites glisser** l'image avec la souris pour la déplacer.
- **Ajuster** : revient à la vue complète.
- **⛶** : affiche l'aperçu en plein écran.
- **⤢ Agrandir** : cache la colonne de gauche pour donner toute la place à l'image. **⤡ Réduire** la ramène.

![Mode Agrandir : l'image occupe toute la largeur](img/36-agrandir.png)

À fort zoom, l'aperçu est redessiné avec plus de finesse (jusqu'à trois fois plus de détails), pas seulement agrandi.

## 45. Ne pas afficher une couleur

À gauche de chaque ligne de la liste des fils se trouve une case à cocher.

1. **Décochez** la case d'une couleur : elle disparaît de l'aperçu (vue normale, relief et 3D).
2. **Recochez-la** pour la faire revenir.

![Une couleur masquée : sa case est décochée](img/37-masquer-couleur.png)

C'est pratique pour voir ce qu'il y a sous une couleur ou pour juger une couleur seule. La couleur masquée reste dans le fichier exporté : le masquage ne change que l'affichage.

## 46. Plusieurs textes, plusieurs polices

1. Dans la zone **Textes sur l'image**, cliquez sur **Gérer les textes**. Un panneau s'ouvre à la place de la colonne de gauche.
2. Cliquez sur **➕ Ajouter un texte** autant de fois que nécessaire.
3. Pour chaque texte : tapez le texte, choisissez la **police**, réglez la **taille** et la **position** avec les curseurs, puis la **couleur du fil**.
4. Pour une autre police, cliquez sur **Importer une police** et choisissez un fichier `.ttf`, `.otf` ou `.woff` téléchargé sur votre ordinateur. Elle apparaît dans la liste de tous les textes.
5. **Fermer** ramène la colonne de gauche.

![Deux textes avec deux polices et deux types de point](img/38-textes-multiples.png)

Le type de point est choisi **automatiquement selon la taille** : l'application mesure l'épaisseur des traits de chaque texte et l'affiche sur sa carte.
- Trait de **moins de 1,2 mm** (petit texte) : point droit le long des lettres.
- Trait de **1,2 à 6 mm** : satin.
- Trait de **plus de 6 mm** (gros texte) : satin sur les parties fines et tatami sur les parties épaisses.

Les points de l'image sont retirés sous les lettres, avec une petite marge : les fils ne se superposent pas. Chaque texte a sa ligne « texte » dans la liste des fils.

## 47. Le sens du fichier DST : annuler l'effet miroir

Si votre texte sort en miroir ou à l'envers, changez le réglage **Sens** de la zone **Exporter**. Il s'applique aux fichiers DST et 10O.

![Le réglage Sens dans la zone Exporter](img/40-sens-export.png)

Les quatre choix :
- **Miroir vertical** (choix par défaut, réglé d'après la remarque d'un effet miroir) ;
- **Miroir horizontal** ;
- **Rotation 180°** ;
- **Sens d'origine**.

Comment trouver le bon :
1. Écrivez une lettre qui ne se ressemble pas à l'envers, par exemple **F** ou **R**, avec **Texte seul**.
2. Exportez le DST, puis ouvrez-le dans votre logiciel de broderie.
3. Si la lettre est lisible dans le bon sens, c'est le bon choix. Sinon, changez **Sens**, exportez à nouveau et regardez encore. Essayez dans l'ordre : vertical, horizontal, 180°, origine.
4. Faites un essai sur une chute avant le vrai travail.

## 48. Corriger les zones directement sur la photo

Le motif est calculé automatiquement, mais une zone peut être mal découpée : un reflet pris pour une couleur, un bout de forme manquant, une tache en trop. Une barre de correction, sous la barre de zoom, permet de retoucher à la main.

![Barre de correction : pinceau actif, couleur choisie à côté du curseur de taille](img/43-barre-corrections.png)

1. **Choisissez la couleur** : cliquez sur une zone de l'image, ou sur une ligne de la liste des fils. La pastille ronde de la barre prend cette couleur.
2. **Pinceau** : cliquez sur **🖌 Pinceau** (le bouton devient orange). Si aucune couleur n'est choisie, cliquez sur une zone de l'image pour la prendre. Puis **glissez** sur l'image : un trait orange transparent montre votre passage. Quand vous relâchez, la zone prend la couleur choisie et le motif est recalculé.
3. **Taille** : le curseur **Taille** règle l'épaisseur du pinceau, de 1 à 20 mm.
4. **Gomme** : cliquez sur **🧽 Gomme**, puis glissez sur les zones à retirer : la broderie disparaît et le tissu réapparaît. La case **Ignorer le fond** doit être cochée.
5. **Annuler** : **↩ Annuler** retire la dernière correction.
6. **Terminer** : cliquez de nouveau sur Pinceau ou Gomme pour le désactiver. Vous pouvez alors zoomer, déplacer l'image et cliquer pour choisir une couleur.

![Avant : l'image convertie. Après : du rouge ajouté en haut et une zone effacée dans le cercle](img/42-corrections-avant-apres.png)

Le bouton **Effacer** (zone **Style**) supprime toutes les corrections et tous les tracés. Les corrections sont conservées quand vous changez les réglages, et elles disparaissent quand vous importez une autre image. Elles ne s'appliquent pas en mode Portrait. Pour fermer un petit trou dans une forme, utilisez plutôt **Fermer une forme** (partie 42).

## 49. Le détourage par IA open source

**Une IA améliore-t-elle la conversion ?** Oui pour les photos qui ont un sujet net (un portrait, un animal, un objet) : une IA de détourage sépare le sujet du fond bien mieux qu'une simple règle de couleurs. On obtient moins de zones inutiles, moins de couleurs gaspillées sur l'arrière-plan et moins de coupes de fil. Pour un logo ou un dessin sur fond uni, elle n'apporte presque rien. Je n'ai pas pu mesurer le gain avec le vrai modèle, qui n'était pas téléchargeable depuis l'environnement où l'application a été écrite : comparez avec et sans sur quelques-unes de vos photos.

L'IA utilisée est **U²-Netp** (licence Apache-2.0), exécutée dans votre navigateur, sur le processeur, avec **ONNX Runtime Web** (licence MIT). Aucune image n'est envoyée sur internet.

![Le trajet d'une photo : IA, masque, broderie](img/45-schema-ia.png)

### Installer l'IA
Le modèle (environ 4,7 Mo) et la bibliothèque ne sont pas dans le projet : un script les télécharge.
- **Avec Docker** : rien à faire. `docker compose up -d --build` télécharge l'IA pendant la construction (internet est nécessaire à ce moment). Pour ne pas l'installer, mettez `WITH_AI: "0"` dans `docker-compose.yml`.
- **Sans Docker, sous Kubuntu** : ouvrez Konsole et tapez ces deux commandes.

```
cd ~/broderieIA
sh scripts/download-ai.sh
```

Le script crée le fichier `models/u2netp.onnx` et le dossier `vendor/ort`. Il vérifie le fichier avec une somme de contrôle et vous prévient si elle est différente.
- **Avec GitHub Pages** : lancez le script sur votre ordinateur, puis téléversez les dossiers `models` et `vendor` sur GitHub (**Add file**, **Upload files**, environ 40 Mo en tout).

### Utiliser l'IA
1. Importez une photo.
2. Dans la barre sous le zoom, cliquez sur **🤖 Détourer**. La première fois, comptez quelques secondes : le modèle se charge.
3. Un message indique « sujet détecté, fond retiré » et la case **sujet seul** se coche : le fond devient blanc, donc non brodé.
4. Pour comparer, décochez **sujet seul**.
5. Réglez **Seuil du détourage IA (%)** dans « Tous les réglages » (famille **Qualité de la photo**) : plus la valeur est haute, plus le sujet est strict.
6. **Modèle…** permet de charger un autre fichier `.onnx` de détourage de type U²-Net (entrée de 320 × 320 points, sortie en carte de saillance).

![La barre de correction et d'IA, avec un message d'aide](img/44-barre-ia.png)

### Si un message d'erreur apparaît
- **« bibliothèque ONNX Runtime introuvable »** : pas d'internet et dossier `vendor/ort` absent. Lancez `sh scripts/download-ai.sh`.
- **« modèle introuvable »** : le fichier `models/u2netp.onnx` manque. Lancez le même script ou utilisez **Modèle…**.
- **« échec de l'analyse »** : le navigateur est trop ancien ou le modèle n'est pas compatible. Essayez un autre navigateur.
- **« using ceil() in shape computation is not yet supported for MaxPool »** : ce message venait du calcul sur la carte graphique (WebGL), que ce modèle ne sait pas faire. Depuis la version 2.5.1, l'IA s'exécute sur le processeur (WebAssembly) : remplacez `index.html` par la nouvelle version. Compter une à trois secondes par photo.

D'autres IA existent (découpage par objets, détection de contours, agrandissement d'image) : elles ne sont pas intégrées, car leurs modèles sont souvent beaucoup plus lourds.

## 50. Ce qui n'est pas encore disponible

- Export EOF, palette Madeira intégrée (à importer vous-même).
- Le **détourage par IA** n'a pas pu être essayé avec le vrai modèle : seule sa liaison avec l'application a été vérifiée (messages d'erreur, préparation de l'image, utilisation du masque).
- Le bon **Sens** d'export dépend de votre logiciel et de votre machine : il n'a pas pu être vérifié ici, d'où les quatre choix de la partie 47.
- Réglages d'Ink/Stitch pas encore intégrés : arrêt de la machine après un objet (dépend de chaque machine) et lecture des polices de lettrage au format Ink/Stitch (remplacée par l'import de polices .ttf et .otf).
- Le satin n'est pas encore soigné aux jonctions entre traits, et la reconnaissance d'écriture n'a pas pu être contrôlée avant livraison : elle dépend d'un chargement depuis internet.
- Parmi les nombreux réglages d'Ink/Stitch, seuls ceux de ce guide sont reliés : le zigzag, les sous-couches de contour, les points de remplissage en spirale ou à motif, et le réglage de départ et d'arrivée ne le sont pas encore.
- Le schéma de montage est un texte, pas encore un dessin.

## 51. Journal des versions

- **Version 2.5.1** : correction du détourage par IA (exécution sur le processeur au lieu de la carte graphique, qui provoquait l'erreur MaxPool), conteneur Docker 2.5.1.
- **Version 2.5** : pinceau, gomme et annulation pour corriger les zones sur la photo, détourage par IA open source (U²-Netp avec ONNX Runtime Web), script de téléchargement et étape Docker pour l'installer, barre de correction et d'IA, noms du sens d'export clarifiés, conteneur Docker 2.5 en deux étapes.
- **Version 2.4** : fermeture des formes (automatique et à la main), regroupement des couleurs pour limiter sauts et coupes de fil (jusqu'à 92 % de coupes en moins sur les photos d'essai), zoom, molette, déplacement, plein écran et mode Agrandir, masquage d'une couleur, plusieurs textes avec polices importées et point choisi selon la taille, réglage du sens du fichier DST et 10O, conteneur Docker 2.4.
- **Version 2.3** : barre de taille du motif au-dessus de la photo, conversion de meilleure qualité (calcul des couleurs en Lab, lissage de la photo, saturation, contraste automatique, angle automatique), plus de couleurs adaptées à l'image (6 à 15, jusqu'à 24 en réglage) et palette générique de 77 fils, boutons Ajouter ou Retirer une couleur, portrait en tons avec jusqu'à 4 couleurs et texte possible, liste des fils plus compacte, conteneur Docker 2.3.
- **Version 2.2** : nouveau design plus vif et plus convivial (couleurs, icônes, bulles d'aide, glisser-déposer, thème sombre), panneaux de réglages qui remplacent la colonne de gauche sans rien cacher, correction du panneau Réglages rapides et du panneau Tous les réglages (leurs curseurs ne réagissaient pas), conteneur Docker 2.2.
- **Version 2.1** : import de polices `.ttf` et `.otf`, colonnes de satin à rails, remplissage guidé par une ligne, sous-couche en zigzag du tatami, optimisation automatique des réglages à chaque changement de style, réglages satin et coupe de fil, point guide des cercles, interface compactée pour tout voir sans défiler, conteneur Docker durci.
- **Version 2.0** : conteneur Docker avec contrôle de santé, réglages de points pour chacune des 15 aiguilles, zigzag, sous-couches de contour et en zigzag, méthodes de remplissage, points de départ, d'arrivée et d'arrêt, texte sur l'image, stabilisateurs dessous et dessus par tissu, rendu 3D avec la carte graphique.
- **Version 1.x** : import d'images, conversion en couleur, gris et noir et blanc, tatami, satin, portrait, exports DST, 10O et EDR, rendu relief, guide en trois formats.
